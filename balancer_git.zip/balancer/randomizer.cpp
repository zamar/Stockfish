#include <cstdlib>
#include <iostream>
#include <cmath>

//Macros

#define Min(x, y) (((x) < (y))? (x) : (y))
#define Max(x, y) (((x) < (y))? (y) : (x))

//Random management initializing

#include "mtwist/mtwist.h"
#include "mtwist/randistrs.h"

mt_state global_mt_state;

void mt_state_init(mt_state *state, uint32_t seed)
{ 
  state->stateptr = 0;
  state->initialized = 0;
  mts_seed32new(state, seed);
}

uint32_t get_true_random_number()
{ 
  uint32_t rnd;
  rnd = time(NULL);

  FILE *ranfile;
  ranfile = fopen("/dev/urandom", "rb");
  if (ranfile != NULL) {
    fread(&rnd, 1, sizeof(uint32_t), ranfile);
    fclose(ranfile);
  } else {
    std::cerr<<"Random file not available! Using time instead!\n";
  }

  return rnd;
}

void random_management_init()
{ 
  mt_state_init(&global_mt_state, get_true_random_number());
}

//Deviation calculations

float calc_dev(int iteration, float value, float minvaluefordeviation, float deviationfactor, float coolingfactor)
{
  return Max(fabs(value), minvaluefordeviation) * deviationfactor * pow(2.0, - coolingfactor * iteration);
}

void calc_new(int iteration, float value, float min, float max,
               float minvaluefordeviation, float deviationfactor, float coolingfactor, float *valuenew1, float *valuenew2)
{
  float std_dev = calc_dev(iteration, value, minvaluefordeviation, deviationfactor, coolingfactor);
  float dev = rds_lnormal(&global_mt_state, 0, std_dev);
  
  *valuenew1 = value + dev;
  *valuenew2 = value - dev;
  //FIXME
  if (*valuenew1 < min) {
    *valuenew1 = min;
  }

  if (*valuenew2 < min) {
    *valuenew2 = min;
  }

  if (*valuenew1 > max) {
    *valuenew1 = max;
  }

  if (*valuenew2 > max) {
    *valuenew2 = max;
  }
}

int rand_round(float value)
{
  if (fmodf(value, 1.0) > rds_luniform(&global_mt_state, 0.0, 1.0)) {
    return int(floorf(value)) + 1;
  } else {
    return int(floorf(value));
  }
}

int main(int argc, char *argv[])
{
  //Initialize random
  random_management_init();

  //Turn buffering off
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  std::cout.rdbuf()->pubsetbuf(NULL, 0);
  std::cin.rdbuf()->pubsetbuf(NULL, 0);

  //Endless loop 
  char line[1024];
  while(std::cin.getline(line, 1024)) {
    //std::cerr<<"Input: "<<line<<"\n";
    int iteration;                                 
    float value;                                 
    float min;
    float max;
    float minvaluefordeviation;
    float deviationfactor;
    float coolingfactor;
     
    if (sscanf(line, "value %d %f %f %f %f %f %f",
        &iteration, &value, &min, &max, &minvaluefordeviation, &deviationfactor, &coolingfactor) != 7) {
      std::cerr<<"Incorrect input. Quitting\n";
      return 1;
    }
 
    float valuenew1;
    float valuenew2;
    if (deviationfactor != 0) {
      calc_new(iteration, value, min, max, minvaluefordeviation, deviationfactor, coolingfactor, &valuenew1, &valuenew2);
    } else {
      valuenew1 = value;
      valuenew2 = value;
    }

    sprintf(line, "result %f %d %f %d", valuenew1, rand_round(valuenew1), valuenew2, rand_round(valuenew2));
    std::cout<<line<<"\n";
  } 
  
  std::cerr<<"Exiting. Broken pipe?";
  
  return EXIT_SUCCESS;
}
